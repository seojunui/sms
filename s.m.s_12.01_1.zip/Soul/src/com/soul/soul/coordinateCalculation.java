package com.soul.soul;

public class coordinateCalculation {
	public int BackUp_x;
	public int BackUp_y;
	public int now_x;
	public int now_y;

}
